<div class="languages_box">
	<span class="red">Ngôn ngữ:</span> 
	<a href="#" class="selected"><img src="<?php echo $imageURL; ?>/gb.gif"/></a>
	<a href="#"><img src="<?php echo $imageURL; ?>/fr.gif" /></a> 
	<a href="#"><img src="<?php echo $imageURL; ?>/de.gif"/></a>
</div>