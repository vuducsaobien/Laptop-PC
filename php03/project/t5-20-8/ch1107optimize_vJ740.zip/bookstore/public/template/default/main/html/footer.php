
<div class="footer">
	<div class="left_footer">
		<img src="<?php echo $imageURL; ?>/footer_logo.gif" alt="" title="" /><br />
		<a href="http://csscreme.com/freecsstemplates/" title="free templates"><img
			src="<?php echo $imageURL; ?>/csscreme.gif" alt="free templates"
			title="free templates" border="0" /></a>
	</div>
	<div class="right_footer">
		<a href="#">home</a> <a href="#">about us</a> <a href="#">services</a>
		<a href="#">privacy policy</a> <a href="#">contact us</a>

	</div>

</div>