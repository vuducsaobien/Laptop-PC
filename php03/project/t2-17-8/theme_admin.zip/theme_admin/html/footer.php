<footer class="main-footer text-sm">
    <strong>Copyright © 2020 <a href="https://www.codethanhthuongthua.asia/">ZendVN</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Hotline 1:</b> 090 5744 470
        ||
        <b>Hotline 2:</b> 0383 308 983
    </div>
</footer>