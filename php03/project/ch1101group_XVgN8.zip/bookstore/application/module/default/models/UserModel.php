<?php
class UserModel{
	public function __construct(){
		echo '<h3>' . __METHOD__ . '</h3>';
	}
}