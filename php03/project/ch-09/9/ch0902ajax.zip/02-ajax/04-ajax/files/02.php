<?php
	$course = array(
						'id'	=> 2,
						'name'	=> 'PHP 1'
					);
	echo json_encode($course);