<footer class="main-footer text-sm">
    <strong>Copyright &copy; 2020 <a href="https://www.zendvn.com/">ZendVN.com</a>.</strong>
    All rights reserved.
</footer>