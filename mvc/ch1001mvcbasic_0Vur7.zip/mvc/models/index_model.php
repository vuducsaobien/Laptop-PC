<?php
class Index_Model{
	public function __construct(){
	}
}