		<div class="footer">
			<h3>Footer</h3>
		</div>
	</div>
</body>
</html>