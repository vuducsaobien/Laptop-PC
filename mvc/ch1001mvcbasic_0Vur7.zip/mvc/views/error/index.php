<div class="content"><?php echo $this->msg;?></div>
