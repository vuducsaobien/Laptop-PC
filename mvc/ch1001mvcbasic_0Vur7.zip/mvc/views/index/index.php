<div class="content">
<?php echo __FILE__;
?></div>

