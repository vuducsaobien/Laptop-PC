<div class="content">
	<h3>Logout</h3>
	Click vào <a href="index.php?controller=index&action=index">đây</a> đề quay về trang chủ
</div>