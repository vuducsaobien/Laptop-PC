<?php
	$array	= glob('abc*');
	
	echo '<pre>';
	print_r($array);
	echo '</pre>';