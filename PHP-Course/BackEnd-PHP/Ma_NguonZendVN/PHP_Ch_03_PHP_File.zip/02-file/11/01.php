<?php
	$array	= glob('*');
	
	echo '<pre>';
	print_r($array);
	echo '</pre>';