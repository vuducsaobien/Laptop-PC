<?php
	$array	= glob('*txt');
	
	echo '<pre>';
	print_r($array);
	echo '</pre>';