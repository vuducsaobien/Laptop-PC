<?php
	$array	= glob('*es');
	
	echo '<pre>';
	print_r($array);
	echo '</pre>';