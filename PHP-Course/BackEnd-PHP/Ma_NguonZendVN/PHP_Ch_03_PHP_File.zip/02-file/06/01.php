<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<?php
	$oldname 	= 'files/test1.txt';
	$newname 	= 'test12.txt';
	
	rename($oldname, $newname);