<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<?php
	$oldname 	= 'files';
	$newname 	= 'files2';
	
	rename($oldname, $newname);