<?php
	$fileName	= 'files/abc.txt';
	//file_put_contents($fileName, null);
	
	unlink($fileName);