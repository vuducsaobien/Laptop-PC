<?php
	$path	= '';
	$path	= 'files/';
	$path	= 'files/abc.txt';
	
	echo realpath($path);