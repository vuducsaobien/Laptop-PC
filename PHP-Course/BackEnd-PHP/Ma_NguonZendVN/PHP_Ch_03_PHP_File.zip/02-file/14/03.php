<?php
	// Thu muc hien tai: D:\xampp\htdocs\php\ch03\02-file\14
	echo getcwd();
	
	chdir('images');
	echo '<br />' . getcwd();