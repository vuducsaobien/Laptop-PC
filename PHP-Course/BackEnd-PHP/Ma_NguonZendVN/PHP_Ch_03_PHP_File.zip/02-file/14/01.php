<?php
	echo getcwd();