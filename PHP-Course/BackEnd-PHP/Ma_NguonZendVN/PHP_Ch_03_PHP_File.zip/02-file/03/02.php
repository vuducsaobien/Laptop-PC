<?php
	$path	=	'/files/abc.txt';
	
	echo dirname($path) . '<br />';
	echo dirname('D:/xampp/htdocs/php/index.php') . '<br />';